/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_102(unsigned *p)
{
    *p = 1492611642U;
}

void setval_350(unsigned *p)
{
    *p = 2496104776U;
}

void setval_147(unsigned *p)
{
    *p = 3284633944U;
}

unsigned getval_352()
{
    return 3344455821U;
}

unsigned addval_327(unsigned x)
{
    return x + 3347662914U;
}

void setval_473(unsigned *p)
{
    *p = 2932299791U;
}

unsigned getval_431()
{
    return 3284633928U;
}

void setval_104(unsigned *p)
{
    *p = 3277378828U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_270()
{
    return 3598828334U;
}

void setval_461(unsigned *p)
{
    *p = 3534015113U;
}

unsigned getval_267()
{
    return 3352726009U;
}

unsigned addval_212(unsigned x)
{
    return x + 3525362073U;
}

unsigned addval_412(unsigned x)
{
    return x + 3380926088U;
}

unsigned addval_126(unsigned x)
{
    return x + 3525364361U;
}

void setval_148(unsigned *p)
{
    *p = 2447411528U;
}

unsigned getval_493()
{
    return 2430634316U;
}

unsigned addval_469(unsigned x)
{
    return x + 3682915977U;
}

unsigned addval_225(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_314(unsigned x)
{
    return x + 3281043853U;
}

unsigned addval_495(unsigned x)
{
    return x + 3247038419U;
}

unsigned getval_175()
{
    return 3525367435U;
}

unsigned getval_183()
{
    return 3529558665U;
}

unsigned addval_339(unsigned x)
{
    return x + 3286276424U;
}

unsigned getval_435()
{
    return 3374369416U;
}

unsigned addval_458(unsigned x)
{
    return x + 3353381192U;
}

unsigned addval_498(unsigned x)
{
    return x + 3675832713U;
}

unsigned addval_211(unsigned x)
{
    return x + 3677935241U;
}

void setval_381(unsigned *p)
{
    *p = 3286280520U;
}

unsigned getval_131()
{
    return 3526934920U;
}

void setval_149(unsigned *p)
{
    *p = 3229928072U;
}

void setval_374(unsigned *p)
{
    *p = 3083059585U;
}

unsigned getval_168()
{
    return 3682910601U;
}

unsigned getval_142()
{
    return 2447411528U;
}

unsigned addval_445(unsigned x)
{
    return x + 3281046153U;
}

unsigned getval_132()
{
    return 3586312841U;
}

unsigned addval_390(unsigned x)
{
    return x + 2430634312U;
}

void setval_277(unsigned *p)
{
    *p = 3374893705U;
}

unsigned getval_180()
{
    return 2425542281U;
}

unsigned getval_324()
{
    return 3523794561U;
}

unsigned addval_465(unsigned x)
{
    return x + 3222847881U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
